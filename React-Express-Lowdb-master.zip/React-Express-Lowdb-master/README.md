# React-Express-Lowdb
Menghubungkan antara react dengan express+lowdb
